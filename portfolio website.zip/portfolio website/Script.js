function submitForm(event) {
  event.preventDefault();
  document.getElementById("form-message").innerText =
    "Thank you! Your message has been sent.";
}